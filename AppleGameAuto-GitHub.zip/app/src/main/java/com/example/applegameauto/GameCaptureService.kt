
package com.example.applegameauto

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

class GameCaptureService : Service() {

    companion object {
        @Volatile var startIntent: Intent? = null
        private const val CHANNEL = "apple_game_auto"
        private const val NOTIFICATION_ID = 1234
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val executor = Executors.newSingleThreadExecutor()

    private var topRatio = 0.20f
    private var bottomRatio = 0.90f
    private var cols = 17
    private var rows = 10
    private var busy = false
    private var lastAction = 0L
    private var noMoveCount = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(
            NOTIFICATION_ID,
            Notification.Builder(this, CHANNEL)
                .setContentTitle("사과게임 자동 플레이")
                .setContentText("게임 화면을 분석하고 있습니다.")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        topRatio = intent?.getFloatExtra("top", 0.20f) ?: 0.20f
        bottomRatio = intent?.getFloatExtra("bottom", 0.90f) ?: 0.90f
        cols = intent?.getIntExtra("columns", 17) ?: 17
        rows = intent?.getIntExtra("rows", 10) ?: 10

        if (projection == null) setupProjection()
        return START_STICKY
    }

    private fun setupProjection() {
        val data = startIntent ?: run {
            stopSelf()
            return
        }

        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(Activity.RESULT_OK, data)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = projection?.createVirtualDisplay(
            "AppleGameAuto",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface,
            object : VirtualDisplay.Callback() {},
            Handler(Looper.getMainLooper())
        )

        reader?.setOnImageAvailableListener({ r ->
            if (busy || System.currentTimeMillis() - lastAction < 350) {
                r.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }

            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy = true

            executor.execute {
                try {
                    processImage(image)
                } finally {
                    image.close()
                    busy = false
                }
            }
        }, Handler(Looper.getMainLooper()))
    }

    private fun processImage(image: Image) {
        val bitmap = imageToBitmap(image) ?: return
        val w = bitmap.width
        val h = bitmap.height

        val top = (h * topRatio).toInt().coerceIn(0, h - 1)
        val bottom = (h * bottomRatio).toInt().coerceIn(top + 1, h)
        val board = Bitmap.createBitmap(bitmap, 0, top, w, bottom - top)

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(board, 0))
            .addOnSuccessListener { result ->
                try {
                    val grid = Array(rows) { IntArray(cols) { 0 } }

                    for (block in result.textBlocks) {
                        for (line in block.lines) {
                            for (element in line.elements) {
                                val raw = element.text.filter { it.isDigit() }
                                if (raw.isEmpty()) continue

                                val value = raw.toIntOrNull() ?: continue
                                if (value !in 1..9) continue

                                val box = element.boundingBox ?: continue
                                val cx = box.centerX()
                                val cy = box.centerY()

                                val c = ((cx.toFloat() / board.width) * cols)
                                    .toInt().coerceIn(0, cols - 1)
                                val r = ((cy.toFloat() / board.height) * rows)
                                    .toInt().coerceIn(0, rows - 1)

                                if (grid[r][c] == 0) grid[r][c] = value
                            }
                        }
                    }

                    val rect = findRectangleSum10(grid)

                    if (rect != null) {
                        noMoveCount = 0
                        performRectangleDrag(
                            rect, top, board.width, board.height
                        )
                    } else {
                        noMoveCount++
                        if (noMoveCount > 15) {
                            stopSelf()
                        }
                    }
                } finally {
                    recognizer.close()
                    board.recycle()
                    bitmap.recycle()
                }
            }
            .addOnFailureListener {
                recognizer.close()
                board.recycle()
                bitmap.recycle()
            }
    }

    data class Rect(
        val top: Int,
        val left: Int,
        val bottom: Int,
        val right: Int
    )

    /*
     * 사과게임의 핵심 규칙:
     * 숫자를 임의로 선택하는 것이 아니라, 하나의 직사각형 영역 안의
     * 숫자 합이 정확히 10이 되도록 영역을 드래그한다.
     *
     * 모든 직사각형을 검사하되, 작은 영역을 우선한다.
     * 숫자가 모두 양수이므로 발견 즉시 합이 10을 넘으면 해당 방향을
     * 더 확장할 필요가 없도록 최적화한다.
     */
    private fun findRectangleSum10(grid: Array<IntArray>): Rect? {
        val prefix = Array(rows + 1) { IntArray(cols + 1) }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                prefix[r + 1][c + 1] =
                    grid[r][c] +
                    prefix[r][c + 1] +
                    prefix[r + 1][c] -
                    prefix[r][c]
            }
        }

        var best: Rect? = null
        var bestArea = Int.MAX_VALUE

        for (r1 in 0 until rows) {
            for (r2 in r1 until rows) {
                for (c1 in 0 until cols) {
                    for (c2 in c1 until cols) {
                        val sum =
                            prefix[r2 + 1][c2 + 1] -
                            prefix[r1][c2 + 1] -
                            prefix[r2 + 1][c1] +
                            prefix[r1][c1]

                        if (sum == 10) {
                            val area = (r2 - r1 + 1) * (c2 - c1 + 1)
                            if (area < bestArea) {
                                bestArea = area
                                best = Rect(r1, c1, r2, c2)
                            }
                        }
                    }
                }
            }
        }

        return best
    }

    private fun performRectangleDrag(
        rect: Rect,
        boardTop: Int,
        boardWidth: Int,
        boardHeight: Int
    ) {
        val service = AppleAccessibilityService.instance ?: return

        // 셀 중앙에서 시작해서 직사각형의 반대쪽 셀 중앙까지 드래그한다.
        val x1 = (rect.left + 0.5f) / cols * boardWidth
        val y1 = boardTop + (rect.top + 0.5f) / rows * boardHeight

        val x2 = (rect.right + 0.5f) / cols * boardWidth
        val y2 = boardTop + (rect.bottom + 0.5f) / rows * boardHeight

        service.drag(x1, y1, x2, y2, 180L)
        lastAction = System.currentTimeMillis()
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )

        buffer.rewind()
        bitmap.copyPixelsFromBuffer(buffer)

        if (bitmap.width == image.width) return bitmap

        return Bitmap.createBitmap(
            bitmap, 0, 0, image.width, image.height
        ).also {
            bitmap.recycle()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL,
                    "사과게임 자동 플레이",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    override fun onDestroy() {
        reader?.close()
        virtualDisplay?.release()
        projection?.stop()
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
