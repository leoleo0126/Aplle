package com.example.applegameauto

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.net.Uri

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 5001
    }

    private lateinit var status: TextView
    private lateinit var top: EditText
    private lateinit var bottom: EditText
    private lateinit var columns: EditText
    private lateinit var rows: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        top = findViewById(R.id.top)
        bottom = findViewById(R.id.bottom)
        columns = findViewById(R.id.columns)
        rows = findViewById(R.id.rows)

        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.captureButton).setOnClickListener {
            val mgr = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            startAutoPlay()
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, GameCaptureService::class.java))
            status.text = "자동 플레이 중지"
        }
    }

    private fun startAutoPlay() {
        if (AppleAccessibilityService.instance == null) {
            status.text = "먼저 자동 터치 권한을 허용하세요."
            return
        }

        val intent = Intent(this, GameCaptureService::class.java).apply {
            putExtra("top", top.text.toString().toFloatOrNull() ?: 0.20f)
            putExtra("bottom", bottom.text.toString().toFloatOrNull() ?: 0.90f)
            putExtra("columns", columns.text.toString().toIntOrNull() ?: 17)
            putExtra("rows", rows.text.toString().toIntOrNull() ?: 10)
        }

        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent)
        else startService(intent)
        status.text = "자동 플레이 실행 중..."
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            GameCaptureService.startIntent = data
            status.text = "화면 캡처 권한 허용 완료. 이제 자동 플레이를 누르세요."
        }
    }
}
