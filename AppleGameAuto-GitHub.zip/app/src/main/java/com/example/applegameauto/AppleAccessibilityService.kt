
package com.example.applegameauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class AppleAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AppleAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun drag(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long = 180L): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

        val path = Path()
        path.moveTo(x1, y1)
        path.lineTo(x2, y2)

        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(stroke)
                .build(),
            null,
            null
        )
    }
}
